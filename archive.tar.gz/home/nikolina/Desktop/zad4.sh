tac novi2.txt > novi.txt
